#read in relevant libraries
library ("rpart")
library ("raster")

#read in table of variables
fire_data <- read.csv(file = 'C:/Users/Andy/Box Sync/Thesis Data/BRT_files/MT_brt.csv', header = TRUE)

#assign burn severity and vegetation type thresholds
high_sev_filter <- subset(fire_data, evi_pct_loss > .5)
veg_filter <- subset(high_sev_filter, veg_type_code == 2045)

#simply changing to an appropriate name
brt_data <- veg_filter

#Separating csv table into unique variables
rdnbr <- brt_data[,4]
veg_cover_pre <- brt_data[,5]
rdnbr_stdev <- brt_data[,6]
southness <- brt_data[,7]
slope <- brt_data[,8]
elevation <- brt_data[,9]
evi_pct_loss <- brt_data[,13]
evi_recov <- brt_data[,14]
scf_post1_anom <- brt_data[,15]
#scf_post2_anom <- brt_data[,16]
#scf_post3_anom <- brt_data[,17]
scf_anom_mean <- brt_data[,18]
#scf_anom_max <- brt_data[,19]
#scf_anom_min <- brt_data[,20]
ppt_post1_anom <- brt_data[,21]
#ppt_post2_anom <- brt_data[,22]
#ppt_post3_anom <- brt_data[,23]
ppt_anom_mean <- brt_data[,24]
#ppt_anom_max <- brt_data[,25]
#ppt_anom_min <- brt_data[,26]
#tmax_july <- brt_data[,27]


#Constructing the initial regression tree (unpruned)
#rpart syntax: (dep. var ~ ind. var1 + ind. var2 ....)

brt1 <- rpart(evi_recov ~ veg_cover_pre + rdnbr + rdnbr_stdev + scf_post1_anom + scf_anom_mean + ppt_post1_anom + ppt_anom_mean + slope + southness + elevation, data = brt_data, method="anova")

printcp(brt1)
par(mfrow=c(1,1))
plotcp(brt1)
summary(brt1)
plot(brt1,uniform=TRUE,main="Full Regression Tree")
text(brt1,use.n=TRUE,all=TRUE,cex=0.8)

#Generate 2 plots: R-square vs. number of splits; Rel. error vs. number of splits
par(mfrow=c(1,2)) #Allows for dual display of plots
rsq.rpart(brt1)

#Pruning the tree: finds cp value associated with minimum 
#cross-validated error (i.e. minimum 'xerror')
cpval = brt1$cptable[which.min(brt1$cptable[,"xerror"]),"CP"]
pbrt1 <- prune(brt1, cp = cpval)

#Option to manually choose cp value 
pbrt1 <- prune(brt1, cp = 0.012862)

#Plot the resulting pruned regression tree
par(mfrow=c(1,1))
plot(pbrt1,uniform=TRUE,main="Pruned Regression Tree")
text(pbrt1,use.n=TRUE,all=TRUE,cex=0.8)
summary(pbrt1)
